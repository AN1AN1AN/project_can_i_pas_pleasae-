Make sure these boxes are checked before submitting your issue - thank you!

- [ ] Ask for help on [discord](https://discord.gg/NKYgCBP) and/or [reddit](https://www.reddit.com/r/box2d)
- [ ] Consider providing a dump file using b2World::Dump
