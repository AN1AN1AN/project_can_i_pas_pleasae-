#include"animatedTexture.h"

AnimatedTexture::AnimatedTexture(std::string filename, int x, int y, int w, int h, int frameC, float animS, ANIM_DIR animD)
	: Texture(filename, x, y, w, h) {

	mTimer = Timer::Instance();

	mStartx = x; 
	mStarty = y; 

	mFrCount = frameC; 
	mAnimSpeed = animS;
	mTimePerFr = mAnimSpeed / mFrCount;
	mAnimTimer = 0.0f; 
	
	mAnimDir = animD; 

	mAnimDone = false; 

	mWrapMode = loop;  
}

AnimatedTexture:: ~AnimatedTexture() {}

void AnimatedTexture::WrapMode(WRAP_MODE mode) {
	mWrapMode = mode;
}

void AnimatedTexture::ResetAnimation() {

	mAnimTimer = 0.0f;
	mAnimDone = false;
}

bool AnimatedTexture::IsAnimating() {

	return !mAnimDone;
}

void AnimatedTexture::Update() {
	if (!mAnimDone) {
		mAnimTimer += mTimer->DeltaTime();  

		if (mAnimTimer >= mAnimSpeed) {

			if (mWrapMode == loop) {

				mAnimTimer -= mAnimSpeed; 
			}else {
				
				mAnimDone = true;  
				mAnimTimer = mAnimSpeed - mTimePerFr; 

			}
		}

		if (mAnimDir == horiz) {
			mClipRect.x =  mStartx + (int)(mAnimTimer / mTimePerFr) * mWidth;  

		} else {
			mClipRect.y = mStarty + (int)(mAnimTimer / mTimePerFr) * mHeight; 
		}
	}
}