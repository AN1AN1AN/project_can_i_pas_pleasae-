#ifndef AUDIOMANAGER_H
#define AUDIOMANAGER_H

#include <mutex>
#include <string>
#include "assetManager.h" 
class AudioManager {
private:
    static AudioManager* sInstance;
    static std::mutex instanceMutex; 
    AssetManager* mAssetMgr;

    AudioManager();

public:
    static AudioManager* Instance();
    static void Release();

    ~AudioManager();

    void PlayMusic(std::string filename, int loops);
    void PauseMusic();
    void ResumeMusic();
    void PlaySFX(std::string filename, int loops, int channel);
};

#endif 