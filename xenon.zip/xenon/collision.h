#ifndef _COLLISION_H
#define _COLLISION_H

#include "player.h"
#include "drone.h"
#include "bullet.h"

class Collision {
public:
    static bool CircleCircleTest(GameEntity* entity1, GameEntity* entity2) {
        Vector2 distanceVec = entity2->Pos() - entity1->Pos();
        float distanceSquared = distanceVec.x * distanceVec.x + distanceVec.y * distanceVec.y;

        float radiiSumSquared = (50 / 2 + 50 / 2) *
            (50 / 2 + 50 / 2);

        return distanceSquared < radiiSumSquared;
    }

    static void CheckCollisions(Player* player, DroneArrayHandler* droneArrayHandler) {
        for (auto drone : droneArrayHandler->GetDrones()) {
            if (CircleCircleTest(player, drone)) {
                player->WasHit();
                return;
            }
        }

        for (size_t i = 0; i < Player::MAX_BULLETS; ++i) {
            Bullet* bullet = player->GetBullets()[i];
            if (!bullet->Active()) continue;
            for (size_t j = 0; j < droneArrayHandler->GetDrones().size(); ++j) {
                Drone* drone = droneArrayHandler->GetDrones()[j];
                if (CircleCircleTest(bullet, drone)) {
                    drone->WasHit();
                    bullet->Reload();
                }
            }
        }

    }
};

#endif // !_COLLISION_H
