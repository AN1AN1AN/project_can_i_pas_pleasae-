#ifndef _SCREENMAHAGER_H
#define _SCREENMANAGER_H

#include "startScreen.h"
#include "inputManager.h"
#include "playScreen.h"
#include "backgroundStars.h"

class ScreenManager {
	private: 
		enum SCREENS {start, play};

		static ScreenManager* sInstance; 
		InputManager* mInput;
		BackgroundStars* mBackground;
		StartScreen* mStartScreen; 
		PlayScreen* mPlayScreen; 
		

		SCREENS mCurrentScreen; 
	 
	public: 
		static ScreenManager* Instance();
		static void Release(); 

		void Update(); 
		void Render(); 

	private: 
		ScreenManager();
		~ScreenManager();
};
#endif