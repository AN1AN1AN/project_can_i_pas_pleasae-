#ifndef _PLAYSCREEN_H
#define _PLAYSCREEN_H

#include "inputManager.h"
#include "backgroundStars.h"
#include "playSidebar.h"
#include "player.h"
#include "level.h"

class PlayScreen : public GameEntity {
	private: 
		Timer* mTimer; 
		InputManager* mInput; 
		AudioManager* mAudio;

		BackgroundStars* mBackground;
		PlaySidebar* mSidebar;
		Level* mLevel;

		Texture* mStartLabel;
		float mGameStartTimer;
		float mGameStartDelay;
		float mLevelStartTimer;
		float mLevelStartDelay; 

		bool mGameStarted; 
		bool mLevelStarted;
		int  mCurrentStage; 

		Player* mPlayer;

	private:
		void StartNextLevel();

	public:
		PlayScreen(); 
		~PlayScreen(); 

		bool GameOver();
		void StartNewGame();
		void Update(); 
		void Render(); 
};
#endif