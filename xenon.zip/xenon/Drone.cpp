#include "drone.h"

bool Drone::sMove = false;

Drone::Drone() {
    mLives = 1;
    mScore = 2000;
    mTimer = Timer::Instance();
    mInput = InputManager::Instance();
    mDrone = new AnimatedTexture("drone_bla.bmp", 0, 0, 32, 32, 16, 1.0f, AnimatedTexture::horiz);
    mDrone->WrapMode(AnimatedTexture::loop);
    mDrone->Parent(this);
    mDrone->Pos(Vector2(100.0f, 100.0f));

    mPath = new BeizerPath();
    mPath->AddCurve({ Vector2(50.0f, 50.0f), Vector2(50.0f, 50.0f), Vector2(200.0f, 50.0f), Vector2(200.0f, 50.0f) }, 4);

    mPoints = new Texture("2000", "xenon_font.ttf", 10, { 192, 192, 192 });

    mSpeed = 3.0f;

    mPointsTimeEnd = 10.0f;
    mPointsTimeStart = 0.0f;
    mBody = nullptr;
}

Drone::~Drone() {
    delete mDrone;
    delete mPoints;
    delete mPath;
    if (mBody) {
        delete mBody;
        mBody = nullptr;
    }
}

int Drone::Score() {
    return mScore;
}

void Drone::Scroll(bool v) {
    sMove = v;
}

void Drone::WasHit() {
    mLives--;
    mVisible = false;
    mPointsTimeStart += mTimer->DeltaTime();
    if (mPointsTimeStart > 0.0f && mPointsTimeStart <= mPointsTimeEnd) {
        mPoints->Pos(Pos(world) + Vector2(10.0f, -50.0f));
        mPoints->Render();
    }
}

void Drone::Visible(bool visible) {
    mVisible = visible;
}

void Drone::HandleMovement() {
    Translate(VEC2_UP * mSpeed, world);

    Vector2 pos = Pos(local);
    if (pos.y > Graphics::Instance()->screen_height) {
        pos.y = 0.0f;
        pos.x = rand() % Graphics::Instance()->screen_width;
        Pos(pos);
    }
}

float Drone::GetSpeed() {
    return mSpeed;
}

void Drone::Update(b2World* world) {
    if (sMove)
        HandleMovement();
    mDrone->Update();
}

void Drone::Render() {
    if (mLives > 0) {
        mDrone->Render();
    }
}

void Drone::Fire(Vector2 pos, b2World* world) {
    Pos(pos);
  
    b2BodyDef bodyDef;
    bodyDef.type = b2_dynamicBody;
    bodyDef.position.Set(pos.x, pos.y);
    mBody = world->CreateBody(&bodyDef);

    b2PolygonShape shape;
    shape.SetAsBox(0.1f, 0.1f); 

    b2FixtureDef fixtureDef;
    fixtureDef.shape = &shape;
    fixtureDef.density = 1.0f;
    fixtureDef.friction = 0.0f;

    mBody->CreateFixture(&fixtureDef);

    
    mBody->SetUserData(this);
}