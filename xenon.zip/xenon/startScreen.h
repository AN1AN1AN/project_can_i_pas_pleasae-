#ifndef _STARTSCREEN_H
#define _STARTSCREEN_H

#include "animatedTexture.h"
#include "inputManager.h"
#include"backgroundStars.h"
#include"scoreboard.h"

class StartScreen: public GameEntity {
	private: 
		InputManager* mInput;

		GameEntity* mTopBar;
		Texture* mPlayerOne;
		Texture* mPlayerTwo; 

		Texture* mLogo; 
		Texture* mBbLogo;
		Texture* mPcLogo;

		GameEntity* mPlayModes;
		Texture* mOnePLayerM;
		Texture* mTwoPLayerM;


		GameEntity* mBottom1;
		GameEntity* mBottom2;
		Texture* mQuiting;
		Texture* mCredits; 

		Texture* mCursor;
		Vector2 mCursorStartPos;
		Vector2 mCursorOffset;
		int mSelectedMode;

		BackgroundStars* mBackground;
	public: 
		StartScreen();
		~StartScreen();

		int SelectedMode();

		void ChangeSelectedMode(int change);

		void Update(); 

		void Render(); 
};
#endif