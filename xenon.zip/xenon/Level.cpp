#include "level.h"
#include "collision.h" // Include collision detection header

Level::Level(int stage, PlaySidebar* sidebar, Player* player) {
    mTimer = Timer::Instance();
    mSidebar = sidebar;
    mSidebar->SetLevel(stage);
    mStars = BackgroundStars::Instance();
    mPlayer = player;
    mPlayerHit = false;
    mPlayerRespawnDelay = 0.3f;
    mPlayerRespawnTimer = 0.0f;
    mGameOverLabel = new Texture("GAME OVER", "xenon_font.ttf", 32, { 192, 192, 192 });
    mGameOverLabel->Parent(this);
    mGameOverLabel->Pos(Vector2(Graphics::Instance()->screen_width * 0.5f, Graphics::Instance()->screen_height * 0.5f));
    mGameOver = false;
    mGameOverDelay = 1.5f;
    mGameOverTimer = 0.0f;
    mGameOverLabelScreen = 1.0f;
    mCurrentState = running;

    b2Vec2 gravity(0.0f, 9.8f);
    mWorld = new b2World(gravity);


    mArrayStartPosition = Vector2(rand() % Graphics::Instance()->screen_width * 0.5f, -220.0f);
    mDroneArrayHandler->SetStartPosition(mArrayStartPosition);
    mDroneArrayHandler->SetMovingDown(true);
    mDroneArrayHandler->SpawnArray(5, 50.0f, mWorld);
}

    Level::~Level() {
        mTimer = NULL;
        mSidebar = NULL;
        mStars = NULL;
        mPlayer = NULL;
        delete mGameOverLabel;
        mGameOverLabel = NULL;
        delete mDroneArrayHandler;
        mDroneArrayHandler = NULL;

        delete mWorld;
        mWorld = nullptr;
    }


    void Level::StartStage() {
        mStageStarted = true;
    }

    void Level::HandleCollision() {
        if (!mPlayerHit) {
            if (InputManager::Instance()->KeyPressed(SDL_SCANCODE_X)) {
                mPlayer->WasHit();
                mSidebar->SetShips(mPlayer->Lives());
                mPlayerHit = true;
                mPlayerRespawnTimer = 0.0f;
                mPlayer->Active(false);
            }
        }
    }

    void Level::HandlePlayerDeath() {
        if (mPlayer->Lives() > 0) {
            if (mPlayerRespawnTimer == 0.0f) {
                mPlayer->Visible(false);
            }
            mPlayerRespawnTimer += mTimer->DeltaTime();
            if (mPlayerRespawnTimer > 0) {
                mPlayer->Active(false);
            }
            if (mPlayerRespawnTimer >= mPlayerRespawnDelay) {
                mPlayer->Active(true);
                mPlayer->Visible(true);
                mPlayerHit = false;
            }
        }
        else if (mPlayer->Lives() == 0) {
            if (mGameOverTimer == 0.0f) {
                mPlayer->Active(false);
                mPlayer->Visible(false);
            }
            mGameOverTimer += mTimer->DeltaTime();
            if (mGameOverTimer >= mGameOverDelay) {
                mCurrentState = gameover;
            }
        }
    }


void Level::Update() {
    if (!mStageStarted) {
        StartStage();
    }

    if (mStageStarted) {
        mStars->Scroll(true);
        mDroneArrayHandler->Update(mWorld); 
        for (auto drone : DroneArrayHandler::GetDrones()) {
            if (Collision::CircleCircleTest(mPlayer, drone)) {
                mPlayer->WasHit();
                mSidebar->SetShips(mPlayer->Lives());
                mPlayerHit = true;
                mPlayerRespawnTimer = 0.0f;
                mPlayer->Active(false);
            }
        }


        for (int i = 0; i < Bullet::MAX_BULLETS; ++i) {
            if (mPlayer->GetBullets()[i]->Active()) {
                for (auto drone : DroneArrayHandler::GetDrones()) {
                    if (Collision::CircleCircleTest(mPlayer->GetBullets()[i], drone)) {
                        drone->WasHit();
                        mPlayer->GetBullets()[i]->Reload();
                        mPlayer->AddScore(drone->Score());
                    }
                }
            }
        }

    
        mPlayer->Visible(true);
        HandleCollision();
        if (mPlayerHit) {
            HandlePlayerDeath();
        }

        if (InputManager::Instance()->KeyPressed(SDL_SCANCODE_N)) {
            mCurrentState = finished;
        }
    }
}

void Level::Render() {
    if (mStageStarted) {
        for (int i = 0; i < 5; ++i) {
            mDroneArrayHandler->Render();
        }
    }

    if (mGameOverTimer >= mGameOverLabelScreen) {
        mGameOverLabel->Render();
        mPlayer->Visible(false);
    }
}

Level::LEVEL_STATE Level::State() {
    return mCurrentState;
}
