#ifndef _ENEMY_H
#define _ENEMY_H

#include "gameEntity.h"
#include "beizerPath.h"
#include "timer.h"
#include <vector>

class Enemy : public GameEntity {
protected:
    Timer* mTimer;
    BeizerPath* mPath;
    int mCurrentWaypoint;
    float mSpeed;

public:
    Enemy();
    virtual ~Enemy();

    void SetPath(BeizerPath* path);
    virtual void HandleMovement();
    virtual void Update();
};

#endif // _ENEMY_H
