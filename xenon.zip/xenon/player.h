#ifndef _PLAYER_H
#define _PLAYER_H

#include "animatedTexture.h"
#include "inputManager.h"
#include "audioManager.h"
#include "bullet.h"
#include "box2d.h"

class Player : public GameEntity {
private:
    b2Body* mBody; 
    Timer* mTimer;
    InputManager* mInput;
    bool mVisible;
    bool mAnimating;
    int mScore;
    int mLives;
    AnimatedTexture* mShip;
    AudioManager* mAudio;
    float mMoveSpeed;
    Vector2 mMoveBounds;
    
    
private:
    void HandleFiring(b2World* world);
    void CreateBody(b2World* world);

public:
    Player();
    ~Player();
    static const int MAX_BULLETS = 10;
    Bullet* mBullets[MAX_BULLETS];
    Bullet** GetBullets() { return mBullets; }
    void HandleMovement(b2World* world); 
    void WasHit();
    void Visible(bool visible);
    bool IsAnimating();
    int Score();
    int Lives();
    void AddScore(int change);
    void Update(b2World* world);
    void Render();
};

#endif // !_PLAYER_H