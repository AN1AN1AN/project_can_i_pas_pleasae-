#include "startScreen.h"

StartScreen::StartScreen() {

	mInput = InputManager::Instance();

	mTopBar = new GameEntity(Vector2(Graphics::Instance()->screen_width * 0.5, 80.0f));
	mPlayerOne = new Texture("1UP", "xenon_font.ttf", 20, { 192, 192, 192 });
	mPlayerTwo = new Texture("2UP", "xenon_font.ttf", 20, { 192, 192, 192 });


	mPlayerOne->Parent(mTopBar);
	mPlayerTwo->Parent(mTopBar);

	mPlayerOne->Pos(Vector2(-Graphics::Instance()->screen_width * 0.35f, 0.0f));
	mPlayerTwo->Pos(Vector2(Graphics::Instance()->screen_width * 0.35f, 0.0f));



	mTopBar->Parent(this);

	mLogo = new Texture("Xlogo.bmp", 0, 0, 507, 223); 
	mLogo->Pos(Vector2(Graphics::Instance()->screen_width * 0.5f, Graphics::Instance()->screen_width * 0.36f));
	mLogo->Parent(this); 

	mPlayModes = new GameEntity(Vector2(Graphics::Instance()->screen_width * 0.5, Graphics::Instance()->screen_height * 0.55));
	mOnePLayerM = new Texture("START ONE PLAYER GAME", "xenon_font.ttf", 32, { 192, 192, 192 });
	mTwoPLayerM = new Texture("START TWO PLAYER GAME", "xenon_font.ttf", 32, { 192, 192, 192 });

	mOnePLayerM->Parent(mPlayModes);
	mTwoPLayerM->Parent(mPlayModes);

	mOnePLayerM->Pos(Vector2(-5.0f, 25.0f));
	mTwoPLayerM->Pos(Vector2(-5.0f, 55.0f));

	mPlayModes->Parent(this);

	mBottom1 = new GameEntity(Vector2(Graphics::Instance()->screen_width * 0.5, Graphics::Instance()->screen_height*0.7));
	mBottom2 = new GameEntity(Vector2(Graphics::Instance()->screen_width * 0.5, Graphics::Instance()->screen_height * 0.7));
	mQuiting = new Texture("QUITING", "xenon_font.ttf", 32, {192,192,192});
	mCredits = new Texture("Copyright 2000 The Bitmap Brothers ", "xenon_font.ttf", 15, { 192,192,192 });

	mBbLogo = new Texture("bblogo.bmp", 0, 0, 72, 109);
	mPcLogo = new Texture("pcflogo.bmp", 0, 0, 150, 70);
	
	mQuiting->Parent(mBottom1);

	mQuiting->Pos(Vector2(-5.0f, -50.0f));
	
	mBottom1->Parent(this);

	mCursor = new Texture("cursor.bmp");
	mCursor->Pos(Vector2(250.0f, 520.0f));
	mCursorStartPos = mCursor->Pos(local);
	mCursorOffset = Vector2(0.0f, 30.0f);
	mSelectedMode = 0;

	mCredits->Parent(mBottom2);
	mBbLogo->Parent(mBottom2);
	mPcLogo->Parent(mBottom2);

	mCredits->Pos(Vector2(-5.0f, 200.0f));
	mBbLogo->Pos(Vector2(-400.0f, 170.0f));
	mPcLogo->Pos(Vector2(400.0f, 195.0f));

	mBottom2->Parent(this);

	mBackground = BackgroundStars::Instance();
	mBackground->Scroll(true);

}

StartScreen::~StartScreen() {
	delete mTopBar;
	mTopBar = NULL;

	delete mPlayerOne;
	mPlayerOne = NULL; 

	delete mPlayerTwo;
	mPlayerTwo = NULL; 

	delete mLogo;
	mLogo = NULL;

	delete mPlayModes;
	mPlayModes = NULL;

	delete mOnePLayerM;
	mOnePLayerM = NULL;

	delete mTwoPLayerM;
	mTwoPLayerM = NULL;

	delete mBottom1; 
	mBottom1 = NULL;

	delete mQuiting;
	mQuiting = NULL;

	delete mBottom2;
	mBottom2 = NULL;

	delete mCredits;
	mCredits = NULL;

	delete mBbLogo;
	mBbLogo = NULL;

	delete mPcLogo;
	mPcLogo = NULL;

	delete mCursor;
	mCursor = NULL;

}

void StartScreen::ChangeSelectedMode(int change) {
	mSelectedMode += change;

	if (mSelectedMode < 0) {
		mSelectedMode = 1;
	}
	else if (mSelectedMode > 1) {
		mSelectedMode = 0;
	}
	mCursor->Pos(mCursorStartPos + mCursorOffset * mSelectedMode);
}

void StartScreen::Update() {
	

	if (mInput->KeyPressed(SDL_SCANCODE_DOWN)) {

		ChangeSelectedMode(1);
	}
	else if (mInput->KeyPressed(SDL_SCANCODE_UP)) {
		
		ChangeSelectedMode(-1);
	}

}

int StartScreen::SelectedMode() {
	return mSelectedMode;    
}

void StartScreen::Render() {
	mPlayerOne->Render(); 
	mPlayerTwo->Render();

	mLogo->Render();

	mCursor->Render();
	mOnePLayerM->Render();
	mTwoPLayerM->Render();

	mQuiting->Render();
	mCredits->Render();
	mBbLogo->Render();
	mPcLogo->Render();
}