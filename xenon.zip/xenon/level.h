#ifndef _LEVEL_H
#define _LEVEL_H
#include "gameEntity.h"
#include "player.h"
#include "playSidebar.h"
#include "BackgroundStars.h"
#include "enemy.h"
#include "droneArray.h"
#include "box2d.h"

class Level : public GameEntity {

public:
	enum LEVEL_STATE { running, gameover, finished };
private: 
	Timer* mTimer;
	PlaySidebar* mSidebar; 
	BackgroundStars* mStars; 
	Player* mPlayer;
	Texture* mGameOverLabel;
	LEVEL_STATE mCurrentState;
	static const int MAX_DRONES = 6;
	static const float DRONE_SPEED;
	const Vector2 VEC2_DOWN = Vector2(0.0f, 1.0f);
	b2World* mWorld;
	
	Vector2 mArrayStartPosition; 
	DroneArrayHandler* mDroneArrayHandler;

	int mStage;
	bool mStageStarted;
	bool mPlayerHit;
	bool mGameOver;
	float mPlayerRespawnDelay;
	float mPlayerRespawnTimer;
	float mGameOverDelay;
	float mGameOverTimer;
	float mGameOverLabelScreen;
	 
private: 
	void StartStage();
	void HandleCollision();
	void HandlePlayerDeath();



public: 

	Level(int Stage, PlaySidebar* sidebar, Player* player); 
	~Level();
	LEVEL_STATE State();
	void Update();
	void Render(); 
	
};
#endif 
