 #ifndef _ANIMATEDTEXTURE_H
#define _ANIMATEDTEXTURE_H

#include "timer.h"
#include "texture.h"

class AnimatedTexture : public Texture {
	public: 
		enum WRAP_MODE{ once = 0, loop = 1};
		enum ANIM_DIR{ horiz = 0 , vert = 1};

	private: 
		Timer* mTimer; 

		int mStartx;
		int mStarty;

		float mAnimTimer; 
		float mAnimSpeed;  
		float mTimePerFr;

		int mFrCount;  

		WRAP_MODE mWrapMode; 
		ANIM_DIR mAnimDir; 

		bool mAnimDone;

	public: 
		AnimatedTexture(std::string filename, int x, int y, int w, int h , int frameC,  float animS, ANIM_DIR animD);
		~AnimatedTexture();

		void WrapMode(WRAP_MODE mode);
		void ResetAnimation();
		bool IsAnimating(); 


		void Update(); 
};

#endif