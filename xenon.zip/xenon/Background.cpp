#include"background.h"

bool Background::sScroll = false; 

void Background::Scroll(bool b) {
	sScroll = b; 
}

Background::Background(int layer) 
	: Texture("stars.bmp", 0, 0,5, 3) {
	mTimer = Timer::Instance();

	int StarColor = rand() % 4;
	mClipRect.x = StarColor * 4;
	Pos(Vector2(rand() % Graphics::Instance()->screen_width, rand() % Graphics::Instance()->screen_height));
	mFlickerTimer = 0.0f; 
	mFlickerSpeed = 0.15f + ((float)rand()/ RAND_MAX) * 0.45f; 

	float invLayer = 1.0f;
	Scale(VEC2_ONE * invLayer);
	mScrollSpeed =3.0f;
}

Background::~Background() {
	mTimer = NULL; 
}


void Background::ScrollBackground() {
	Translate(VEC2_UP * mScrollSpeed, world);

	Vector2 pos = Pos(local); 
	if (pos.y > Graphics::Instance()->screen_height) {
		pos.y = 0.0f;
		pos.x = rand() % Graphics::Instance()->screen_width;
		Pos(pos);
	}
}

void Background::Update() {
	mFlickerTimer += mTimer->DeltaTime(); 
	if (mFlickerTimer >= mFlickerSpeed) {

		mVisible = !mVisible;
		mFlickerTimer = 0.0f; 
	}

	if (sScroll)
		ScrollBackground(); 
}

void Background::Render() {
	if (mVisible)
		Texture::Render(); 
}