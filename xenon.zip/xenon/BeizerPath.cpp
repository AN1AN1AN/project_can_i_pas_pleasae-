#include "beizerPath.h"

BeizerPath::BeizerPath() {

}

BeizerPath::~BeizerPath() {

}

void BeizerPath::AddCurve(Beizer curve, int samples) {

	mCurve.push_back(curve);
	mSamples.push_back(samples);
}

void BeizerPath::Sample(std::vector<Vector2>* samplesPath) {

	for (int i = 0; i < mCurve.size(); i++) {
		for (float t = 0; t <= 1.0f; t += (1.0f / mSamples[i])) {
			samplesPath->push_back(mCurve[i].CalculatePoint(t));
		}
	}

}

void BeizerPath::SampleWithRepeat(std::vector<Vector2>* sampledPath) {

    Sample(sampledPath);

   
    for (int i = mCurve.size() - 1; i >= 0; i--) {
        for (float t = 1.0f; t >= 0.0f; t -= (1.0f / mSamples[i])) {
            sampledPath->push_back(mCurve[i].CalculatePoint(t));
        }
    }

    int originalSize = sampledPath->size();
    int desiredPathLength = originalSize * 6;

    while (sampledPath->size() < desiredPathLength) {
        Sample(sampledPath);
    }
}