#include "bullet.h"

Bullet::Bullet() {
    mTimer = Timer::Instance();
    mSpeed = 1000.0f;
    mTexture = new Texture("missile.bmp", 0, 36, 16, 12);
    mTexture->Parent(this);
    mTexture->Pos(VEC2_ZERO);

    Reload();
}

Bullet::~Bullet() {
    mTimer = NULL;

    delete mTexture;
    mTexture = NULL;

 
    if (mBody) {
        delete mBody;
        mBody = nullptr;
    }
}

void Bullet::Fire(Vector2 pos, b2World* world) {
    Pos(pos);
    Active(true);

   
    b2BodyDef bodyDef;
    bodyDef.type = b2_dynamicBody;
    bodyDef.position.Set(pos.x, pos.y);
    mBody = world->CreateBody(&bodyDef);

    b2PolygonShape shape;
    shape.SetAsBox(0.1f, 0.1f); 

    b2FixtureDef fixtureDef;
    fixtureDef.shape = &shape;
    fixtureDef.density = 1.0f;
    fixtureDef.friction = 0.0f;
    fixtureDef.filter.categoryBits = CATEGORY_BULLET;
    fixtureDef.filter.maskBits = CATEGORY_ENEMY; 

    mBody->CreateFixture(&fixtureDef);
}

void Bullet::Reload() {
    Active(false);
   
    if (mBody) {
        delete mBody;
        mBody = nullptr;
    }
}

void Bullet::Update() {
    if (Active()) {
        Translate(-VEC2_UP * mSpeed * mTimer->DeltaTime(), local);
        Vector2 pos = Pos();
        if (pos.y < -OFFSCREEN_BUFFER || pos.y > Graphics::Instance()->screen_height + OFFSCREEN_BUFFER) {
            Reload();
        }
    }
}

void Bullet::Render() {
    if (Active()) {
        mTexture->Render();
    }
}