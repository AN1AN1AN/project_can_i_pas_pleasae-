#ifndef _BACKGRLAYER_H
#define _BACKGRLAYER_H

#include "background.h"

class BackgrLayer {
	private:	
		static const int STARCOUNT = 30;
		Background* mLayer[STARCOUNT]; 

	public: 
		void Update(); 
		void Render(); 
		BackgrLayer(int layer); 
		~BackgrLayer(); 
	};
#endif