#ifndef _SCOREBOARD_H
#define _SCOREBOARD_H

#include "timer.h"
#include <vector>
#include"texture.h"
#include"gameEntity.h"


class Scoreboard : public  GameEntity{
	private: 
		std::vector<Texture*> mScore; 

	public: 
		Scoreboard(); 
		~Scoreboard(); 

		void Score(int score);

		void Render(); 

	private: 
		void ClearScore(); 
};
#endif