#ifndef _BEIZERPATH_H
#define _BEIZERPATH_H
#include "mathHelper.h"
#include <vector>

class BeizerPath {

private:

	std::vector<Beizer> mCurve;
	std::vector<int> mSamples;

public: 

	BeizerPath();
	~BeizerPath();

	void AddCurve(Beizer curve, int samples);
	void Sample(std::vector<Vector2>* sampledPath);
	void SampleWithRepeat(std::vector<Vector2>* sampledPath);
};

#endif
