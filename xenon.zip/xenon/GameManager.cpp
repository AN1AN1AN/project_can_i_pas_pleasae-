#include "gameManager.h"
//#include "BackgroundStars.cpp"
#include "AssetManager.cpp"
#include<time.h>

GameManager* GameManager::sInstance = NULL;

GameManager* GameManager::Instance() {	
	if (sInstance == NULL)
		sInstance = new GameManager();

	return sInstance; 
}
 
void GameManager::Release() {	
	delete sInstance; 
	sInstance = NULL;  
}

GameManager::GameManager(){
	srand(time(0));
	
	mQuit = false; 
	mGraphics = Graphics::Instance();

	if (!Graphics::Initialized())
		mQuit = true;

	mAssetMng = AssetManager::Instance();

	mInputMng = InputManager::Instance();

	mAudioMng = AudioManager::Instance(); 

	mTimer = Timer::Instance(); 

	mScreenMng = ScreenManager::Instance(); 

	mStars = BackgroundStars::Instance();
}

GameManager::~GameManager() {

	AudioManager::Release(); 
	mAudioMng = NULL; 
	
	AssetManager::Release();
	mAssetMng = NULL;

	Graphics::Release();
	mGraphics = NULL;

	InputManager::Release(); 
	mInputMng = NULL;

	Timer::Release();
	mTimer = NULL;

	BackgroundStars::Release();
	mStars = NULL;

	ScreenManager::Release(); 
	mScreenMng = 0; 
}

void GameManager::EarlyUpdate() {
	mTimer->Reset();
	mInputMng->Update(); 
}

void GameManager::Update() {
	mStars->Update();
	mScreenMng->Update();
}

void GameManager::LateUpdate() {
	mInputMng->UpdatePrevInp();
//	mTimer->Reset(); 
}

void GameManager::Render() {
	mGraphics->ClearBackBuffer(); 
	mStars->Render();
	mScreenMng->Render(); 

	mGraphics->Render();
}


void GameManager::Run() {
	while (!mQuit) {		
		mTimer->Update(); 

		while (SDL_PollEvent(&mEvents) != 0) {
			if (mEvents.type  == SDL_QUIT) {
				mQuit = true; 
			}
       	}
		if (mTimer->DeltaTime() >=( 1.0f / FRAME_RATE)) {
			mInputMng->Update();
	    
			if (mInputMng->KeyDown(SDL_SCANCODE_1)) {
				mAudioMng->PlaySFX("game_sound.wav", 0,  1);
			}
			
			if (mInputMng->KeyPressed(SDL_SCANCODE_W)) {
				printf("W pressed"); 
			}
			
			if (mInputMng->KeyReleased(SDL_SCANCODE_W) ){
				printf("W released");
			}

			mGraphics->ClearBackBuffer();;
			mStars->Render();
			GameManager::Instance()->Update();
			mScreenMng->Render();
			mGraphics->Render();	
			
			
			mInputMng->UpdatePrevInp(); 

			mTimer->Reset(); 
		}
	}
}