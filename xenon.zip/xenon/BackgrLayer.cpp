#include"backgrLayer.h"

BackgrLayer::BackgrLayer(int layer) {
	for (int i = 0; i < STARCOUNT; i++) {
		mLayer[i] = new Background(layer);
	}
}

BackgrLayer::~BackgrLayer() {
	for (int i = 0; i < STARCOUNT; i++) {
		delete mLayer[i];
		mLayer[i] = NULL;
	}
}

void BackgrLayer::Update() {
	for (int i = 0; i < STARCOUNT; i++) {
		mLayer[i]->Update(); 
	}
}

void BackgrLayer::Render() {
	for (int i = 0; i < STARCOUNT; i++) {
		mLayer[i]->Render();
	}
}