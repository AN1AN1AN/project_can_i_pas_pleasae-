#ifndef _PLAYER_H
#define _PLAYER_H

#include "animatedTexture.h"
#include "inputManager.h"
#include "audioManager.h"
#include "bullet.h"
#include "box2d.h"

class Player : public GameEntity {
private:
    b2Body* mBody; 
    Timer* mTimer;
    InputManager* mInput;
    bool mVisible;
    bool mAnimating;
    int mScore;
    int mLives;
    AnimatedTexture* mShip;
    AudioManager* mAudio;
    float mMoveSpeed;
    Vector2 mMoveBounds;

    Bullet* mBullets[MAX_BULLETS];

private:
    void HandleFiring(b2World* world);
    void CreateBody(b2World* world);

public:
    Player();
    ~Player();
    void HandleMovement(b2World* world);
    void WasHit();
    void Visible(bool visible);
    bool IsAnimating();
    int Score();
    int Lives();
    void AddScore(int change);
    void Update(b2World* world); 
    void Render();
};

#endif // !_PLAYER_H

#include "player.h"

Player::Player() {
    mTimer = Timer::Instance();
    mInput = InputManager::Instance();
    mAudio = AudioManager::Instance();

    mVisible = false;
    mAnimating = false;
    mScore = 0;
    mLives = 3;

    mShip = new AnimatedTexture("Ship1.bmp", 192, 0, 64, 63, 1, 1.0f, AnimatedTexture::horiz);
    mShip->Parent(this);
    mShip->Pos(VEC2_ZERO);

    mMoveSpeed = 200.0f;
    mMoveBounds = Vector2(30.0f, 990.0f);

    for (int i = 0; i < MAX_BULLETS; i++) {
        mBullets[i] = new Bullet();
    }
}

Player::~Player() {
    delete mShip;

    for (int i = 0; i < Bullet::MAX_BULLETS; i++) {
        delete mBullets[i];
    }

    if (mBody) {
        delete mBody;
        mBody = nullptr;
    }
}

void Player::CreateBody(b2World* world) {
    b2BodyDef bodyDef;
    bodyDef.type = b2_dynamicBody;
    bodyDef.position.Set(Pos().x, Pos().y);
    mBody = world->CreateBody(&bodyDef);

    b2PolygonShape shape;
    shape.SetAsBox(0.1f, 0.1f); 

    b2FixtureDef fixtureDef;
    fixtureDef.shape = &shape;
    fixtureDef.density = 1.0f;
    fixtureDef.friction = 0.0f;
    fixtureDef.filter.categoryBits = CATEGORY_PLAYER;
    fixtureDef.filter.maskBits = CATEGORY_ENEMY | CATEGORY_BULLET;

    mBody->CreateFixture(&fixtureDef);
}

void Player::HandleMovement(b2World* world) {
    if (Active() && mInput->KeyDown(SDL_SCANCODE_RIGHT)) {
        Translate(VEC2_RIGHT * mMoveSpeed * mTimer->DeltaTime(), world);
    }
    else if (Active() && mInput->KeyDown(SDL_SCANCODE_LEFT)) {
        Translate(-VEC2_RIGHT * mMoveSpeed * mTimer->DeltaTime(), world);
    }

    Vector2 pos = Pos(local);
    if (pos.x < mMoveBounds.x) {
        pos.x = mMoveBounds.x;
    }
    else if (pos.x > mMoveBounds.y) {
        pos.x = mMoveBounds.y;
    }

    Pos(pos);
}

void Player::HandleFiring(b2World* world) {
    if (mInput->KeyPressed(SDL_SCANCODE_SPACE)) {
        for (int i = 0; i < MAX_BULLETS; i++) {
            if (!mBullets[i]->Active()) {
                mBullets[i]->Fire(Pos(), world);
                break;
            }
        }
    }
}

void Player::Visible(bool visible) {
    mVisible = visible;
}

bool Player::IsAnimating() {
    return mAnimating;
}

int Player::Score() {
    return mScore;
}

int Player::Lives() {
    return mLives;
}

void Player::AddScore(int change) {
    mScore += change;
}

void Player::WasHit() {
    mLives--;
    mAnimating = true;
    Active(false);
}

void Player::Update(b2World* world) {
    if (mAnimating) {
        mAnimating = !mShip->IsAnimating();
    }
    else {
        if (Active()) {
            HandleMovement(world);
            HandleFiring(world);
        }
    }

    for (int i = 0; i < MAX_BULLETS; i++) {
        mBullets[i]->Update();
    }
}

void Player::Render() {
    if (mVisible) {
        if (mAnimating) {
            mShip->Render();
        }
        else {
            mShip->Render();
        }
    }

    for (int i = 0; i < MAX_BULLETS; i++) {
        mBullets[i]->Render();
    }
}
