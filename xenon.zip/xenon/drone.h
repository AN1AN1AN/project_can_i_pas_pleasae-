#ifndef _DRONE_H
#define _DRONE_H
#include "enemy.h"
#include "timer.h"
#include "beizerPath.h"
#include "animatedTexture.h"
#include "texture.h"
#include "inputManager.h"
#include "box2d.h"

class Drone : public Enemy {
private:
    const float EPSILON = 0.0001f;
    const int OFFSCREEN_BUFFER = 10;
    static bool sMove;
    AnimatedTexture* mDrone;
    Timer* mTimer;
    BeizerPath* mPath;
    Texture* mPoints;
    float mPointsTimeEnd;
    float mPointsTimeStart;
    int mLives;
    int mScore;
    bool mVisible;
    InputManager* mInput;
    float mSpeed;
    b2Body* mBody;
public:
    Drone();
    ~Drone();
    void HandleMovement();
    void WasHit();
    float GetSpeed();
    static void Scroll(bool b);
    int Score();
    void Visible(bool visible);
    void Update(b2World* world); 

    void Fire(Vector2 pos, b2World* world);
};

#endif // !_DRONE_H