#include "playScreen.h"

PlayScreen::PlayScreen() {

	mTimer = Timer::Instance();
	mInput = InputManager::Instance();
	mAudio = AudioManager::Instance();

	mBackground = BackgroundStars::Instance();

	mSidebar = new PlaySidebar();
	mSidebar->Parent(this);
	mSidebar->Pos(Vector2(Graphics::Instance()->screen_width * 0.5f, Graphics::Instance()->screen_height * 0.05f));


	mStartLabel = new Texture("START", "xenon_font.ttf", 32, { 192, 192, 192 });
	mStartLabel->Parent(this);
	mStartLabel->Pos(Vector2(Graphics::Instance()->screen_width * 0.5f, Graphics::Instance()->screen_height * 0.5f));

	mGameStartDelay = 0.5f;
	mLevelStartDelay = 0.5f;
	mLevelStarted = false;

	mLevel = NULL;
	mPlayer = NULL;

}

	PlayScreen::~PlayScreen() {
		mTimer = NULL;
		mInput = NULL;

		mBackground = NULL;

		delete mSidebar;
		mSidebar = NULL;

		delete mPlayer;
		mPlayer = NULL;

		delete mStartLabel;
		mStartLabel = NULL;

		delete mLevel;
		mLevel = NULL;

	
	}

	void PlayScreen::StartNextLevel() {
		mCurrentStage++;
		mLevelStartTimer = 0.0f;
		mLevelStarted = true;
		mSidebar->SetLevel(mCurrentStage);

		delete mLevel;
		mLevel = new Level(mCurrentStage, mSidebar, mPlayer);
	}

	void PlayScreen::StartNewGame() {

		delete mPlayer;
		mPlayer = new Player();
		mPlayer->Parent(this);
		mPlayer->Pos(Vector2(Graphics::Instance()->screen_width * 0.5f, Graphics::Instance()->screen_height * 0.8f));
		mPlayer->Update();
		//mPlayer->HandleMovement();
		mBackground->Scroll(false);
		mSidebar->SetHighScore(3000);
		mSidebar->SetShips(mPlayer->Lives());
		mSidebar->SetPlayerScore(mPlayer->Score());
		mSidebar->SetLevel(0);
		mGameStarted = false;
		mLevelStarted = false;

		//	mAudio->PlayMusic("music_game.wav", 1);
		mCurrentStage = 0;

	}

	bool PlayScreen::GameOver() {

		if (!mLevelStarted) {
			return false;
		}

		return (mLevel->State() == Level::gameover);
	}

	void PlayScreen::Update() {

		if (mGameStarted) {

			if (!mLevelStarted) {
				mLevelStartTimer += mTimer->DeltaTime();
				if (mLevelStartTimer >= mLevelStartDelay)
					StartNextLevel();
			}
		}
		else {
			mGameStartTimer += mTimer->DeltaTime();
			if (mGameStartTimer >= mGameStartDelay) {

				mGameStarted = true;
				mPlayer->Visible(true);
			}
		}

		if (mGameStarted) {

			if (mCurrentStage > 0) {

				mSidebar->Update();

				if (mLevelStarted) {

					mLevel->Update();
					if (mLevel->State() == Level::finished) {
						mLevelStarted = false;
					}
				}
				mPlayer->Update(mWorld);
				mPlayer->HandleMovement();
			}
		}

		mSidebar->Update();
	}


void PlayScreen::Render() {
	mSidebar->Render();

	if (!mGameStarted) {
		mStartLabel->Render();
	}
	if (mGameStarted ) {
		if (mLevelStarted) {
			mLevel->Render();

		}
		mPlayer->Render();
	}
}