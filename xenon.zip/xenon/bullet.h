#ifndef _BULLET_H
#define _BULLET_H

#include "texture.h"
#include "timer.h"
#include "box2d.h"

class Bullet : public GameEntity {
private:
    b2Body* mBody;
    const int OFFSCREEN_BUFFER = 10;
    Timer* mTimer;
    float mSpeed;
    Texture* mTexture;

public:
    
     static const int MAX_BULLETS = 10;
    Bullet();
    ~Bullet();

    void Fire(Vector2 pos, b2World* world);
    void Reload();
    void Update();
    void Render();
};

#endif
