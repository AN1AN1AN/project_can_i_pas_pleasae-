#include "droneArray.h"
#include <cstdlib>

std::vector<Drone*> DroneArrayHandler::mDrones;
Vector2 DroneArrayHandler::mStartPosition;
bool DroneArrayHandler::mMovingDown;

void DroneArrayHandler::SetStartPosition(const Vector2& startPosition) {
    mStartPosition = startPosition;
}

void DroneArrayHandler::SetMovingDown(bool movingDown) {
    mMovingDown = movingDown;
}

void DroneArrayHandler::SpawnArray(int numDrones, float verticalSpacing, b2World* world) {
    mDrones.clear();
    for (int i = 0; i < numDrones; ++i) {
        Drone* drone = new Drone();
        Vector2 position = mStartPosition + Vector2(0.0f, i * verticalSpacing);
        drone->Pos(position);
      
        drone->Fire(position, world);
        mDrones.push_back(drone);
    }
}

static std::vector<Drone*>& GetDrones() { return mDrones; }

void DroneArrayHandler::Update(b2World* world) {
    Vector2 movementDirection = mMovingDown ? VEC2_UP : -VEC2_UP;
    for (auto drone : mDrones) {
        drone->Translate(movementDirection * 1, GameEntity::world);
        drone->Update(world);
    }

  
}

void DroneArrayHandler::Render() {
    for (auto drone : mDrones) {
        drone->Render();
    }
}
