#ifndef _GAMEMANAGER_H
#define _GAMEMANAGER_H

#include "graphics.h"
#include "animatedTexture.h"
#include<string>
#include "audioManager.h"
#include "screenManager.h"
#include "backgroundStars.h"


 class GameManager {
	private: 
		static GameManager* sInstance; 

		const int FRAME_RATE = 120; 

		bool mQuit; 
		Graphics* mGraphics;
		AssetManager* mAssetMng;
		InputManager* mInputMng; 
		AudioManager* mAudioMng; 

		Timer* mTimer;

		SDL_Event mEvents; 

		ScreenManager* mScreenMng; 
		BackgroundStars* mStars;
 
	public:
		static  GameManager* Instance();
		static void Release(); 

		void Run();

	private:
		GameManager();
		~GameManager();
		void EarlyUpdate();
		void Update();
		void LateUpdate();
		void Render();
};
#endif