#include "playSidebar.h"
#include "Scoreboard.cpp"

PlaySidebar::PlaySidebar() {
	mTimer = Timer::Instance();
	mAudio = AudioManager::Instance();
	mBackground = new Texture("background.bmp");
	mBackground->Parent(this);
	mBackground->Pos(Vector2(0.0f, 380.0f));
	mBackground->Scale(Vector2(3.5f, 10.0f));

	mHighLabel = new Texture("HI", "xenon_font.ttf", 15, { 192, 192, 192 });
	mHighLabel->Parent(this);
	mHighLabel->Pos(Vector2(-30.0f, 5.0f));

	mScoreLabel = new Texture("SCORE", "xenon_font.ttf", 15, { 192, 192, 192 });
	mScoreLabel->Parent(this);
	mScoreLabel->Pos(Vector2(20.0f, 5.0f));

	mHighScoreb = new Scoreboard();
	mHighScoreb->Parent(this);
	mHighScoreb->Pos(Vector2(20.0f,18.0f));

	mPlayerOneLabel = new Texture("1UP", "xenon_font.ttf", 15, { 192,192,192 });
	mPlayerOneLabel->Parent(this);
	mPlayerOneLabel->Pos(Vector2(-Graphics::Instance()->screen_width * 0.35f, 5.0f));
	mPlayerOneSc = new Scoreboard();
	mPlayerOneSc->Parent(this);
	mPlayerOneSc->Pos(Vector2(-350.0f, 20.0f));
	
	mShips = new GameEntity();
	mShips->Parent(this); 
	mShips->Pos(Vector2(-450.0f, 750.0f));

	for (int i = 0; i < MAX_SHIP_TEXTURES; i++) {

		mShipTextures[i] = new Texture("PULife.bmp");
		mShipTextures[i]->Parent(mShips);
		mShipTextures[i]->Pos(Vector2(32.0f * (i % 3), 70 *(i/3) ));

	}

	mFlagTimer = 0.0f; 
	mFlagInterval = 0.5f;

	mFlags = new GameEntity();
	mFlags->Parent(this);
	mFlags->Pos(Vector2(-40.0f, 650.0f));
}

PlaySidebar::~PlaySidebar() {
	mTimer = NULL;
	mAudio = NULL;

	delete mBackground;
	mBackground = NULL;

	delete mHighLabel;
	mHighLabel = NULL;

	delete mScoreLabel;
	mScoreLabel = NULL;

	delete mHighScoreb;
	mHighScoreb = NULL;

	delete mPlayerOneLabel;
	mPlayerOneLabel = NULL;

	delete mPlayerOneSc; 
	mPlayerOneSc = NULL;

	delete mShips;
	mShips = NULL;

	for (int i = 0; i < MAX_SHIP_TEXTURES; i++) {
		delete mShipTextures[i];
		mShipTextures[i] = NULL;
	}

	delete mFlags;
	mFlags = NULL;

}




void PlaySidebar::SetHighScore(int score) {
	mHighScoreb->Score(score);

}

void PlaySidebar::SetPlayerScore(int score) {
	mPlayerOneSc->Score(score);
}

void PlaySidebar::SetShips(int ships) {

	mTotalShips = ships;
}

void PlaySidebar::SetLevel(int level) {

	mRemainingLevels = level; 

}

void PlaySidebar::Update() {

	if (mRemainingLevels > 0) {
		mFlagTimer += mTimer->DeltaTime();
		if (mFlagTimer >= mFlagInterval) {


			mFlagTimer = 0.0f;
		 }
	 }

}

void PlaySidebar::Render() {
	mBackground->Render();
	mHighLabel->Render();
	mScoreLabel->Render();

	mPlayerOneLabel->Render();
	mHighScoreb->Render();
	mPlayerOneSc->Render();

	for (int i = 0; i < MAX_SHIP_TEXTURES && i<mTotalShips; i++) {
		mShipTextures[i]->Render();
	}

	
}
