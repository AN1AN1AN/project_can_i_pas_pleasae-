#ifndef _INPUTMANAGER_H
#define _INPUTMANAGER_H

#include <SDL.h>
#include <string.h>
#include "mathHelper.h"

class InputManager {
	private:
		static InputManager* sInstance; 

		Uint8* mPrevKeyState; 
		const Uint8* mKeyState; 
		int mKeyLength; 

		Uint32 mPrevMouseState;
		Uint32 mMouseState; 

		int mMousex; 
		int mMousey; 

	public: 
		enum MOUSE_BUTTON { left = 0, right, middle, back, forward };

		static InputManager* Instance();
		static void Release();

		bool KeyDown(SDL_Scancode scanCode);
		bool KeyPressed(SDL_Scancode scanCode);
		bool KeyReleased(SDL_Scancode scanCode);

		bool MouseButtonDown(MOUSE_BUTTON button);
		bool MouseButtonPressed(MOUSE_BUTTON button);
		bool MouseButtonReleased(MOUSE_BUTTON button);

		Vector2 MousePos(); 

		void Update();
		void UpdatePrevInp();

	private:
		InputManager();
		~InputManager();
};
#endif 