#include "enemy.h"
#include "graphics.h"
#include <cstdlib>

Enemy::Enemy() : mTimer(nullptr), mPath(nullptr), mCurrentWaypoint(0), mSpeed(0.0f) {
    mTimer = Timer::Instance();
}

Enemy::~Enemy() {
    delete mPath;
    mPath = nullptr;
    mTimer = nullptr;
}

void Enemy::SetPath(BeizerPath* path) {
    mPath = path;
}

void Enemy::HandleMovement() {
}

void Enemy::Update() {
}
