#ifndef _PLAYSIDEBAR_H
#define _PLAYSIDEBAR_H

#include "timer.h"
#include "scoreboard.h"
#include "audiomanager.h"

class PlaySidebar: public GameEntity {
	private:
		Timer* mTimer;
		AudioManager* mAudio; 

		Texture* mBackground;
		Texture* mHighLabel;
		Texture* mScoreLabel;
		Scoreboard* mHighScoreb;
		Texture* mPlayerOneLabel;
		Scoreboard* mPlayerOneSc;

		static const int MAX_SHIP_TEXTURES = 3;
		GameEntity* mShips;
		Texture* mShipTextures[MAX_SHIP_TEXTURES];
		int mTotalShips;

		GameEntity* mFlags; 
		float mFlagTimer; 
		float mFlagInterval;
		int mFlagLevel;
		int mRemainingLevels;
	public: 

		PlaySidebar(); 
		~PlaySidebar();

		void SetHighScore(int score);
		void SetPlayerScore(int score);
		void SetShips(int ships);
		void SetLevel(int level);
		void Update(); 
		void Render(); 
};
#endif