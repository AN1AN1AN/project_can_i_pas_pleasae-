#ifndef _BACKGROUND_H
#define _BACKGROUND_H

#include "timer.h"
#include "Texture.h"
#include "graphics.h"


class Background : public Texture {
	private: 
		static bool sScroll;

		Timer* mTimer; 

		bool mVisible; 
		float mFlickerTimer; 
		float mFlickerSpeed; 

		float mScrollSpeed; 

	public: 
		static void Scroll(bool b);
	
		Background(int layer);
		~Background();

		void Update();
		void Render();

	private : 
		void ScrollBackground(); 
	};
#endif 