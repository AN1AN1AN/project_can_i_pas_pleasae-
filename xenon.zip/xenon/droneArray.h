#ifndef DRONE_ARRAY_H
#define DRONE_ARRAY_H

#include "drone.h"
#include <vector>
#include "box2d.h"
class DroneArrayHandler {
private:
    static std::vector<Drone*> mDrones;
    static Vector2 mStartPosition;
    static bool mMovingDown;
    Timer* mTimer;

public:
    static void SetStartPosition(const Vector2& startPosition);
    static void SetMovingDown(bool movingDown);
    static std::vector<Drone*>& GetDrones() { return mDrones; }
    static void SpawnArray(int numDrones, float verticalSpacing, b2World* world); 
    static void Update(b2World* world); 
    static void Render();
};

#endif // DRONE_ARRAY_HANDLER_H
