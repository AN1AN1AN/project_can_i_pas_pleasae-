#include "inputManager.h"

InputManager* InputManager::sInstance = NULL;

InputManager* InputManager::Instance() {
	if (sInstance == NULL)
		sInstance = new InputManager();

	return sInstance; 
}

void InputManager::Release() {
	delete sInstance;
	sInstance = NULL;
}

InputManager::InputManager() {
	mKeyState = SDL_GetKeyboardState(&mKeyLength); 
	mPrevKeyState = new Uint8[mKeyLength]; 
	memcpy(mPrevKeyState, mKeyState, mKeyLength);
}


InputManager::~InputManager() {
	delete[] mPrevKeyState; 
	mPrevKeyState = NULL; 
}

bool InputManager::KeyDown(SDL_Scancode scanCode) {
	return (mKeyState[scanCode] != 0);
}


bool InputManager::KeyPressed(SDL_Scancode scanCode) {
	return (mPrevKeyState[scanCode]) == 0 && (mKeyState[scanCode] != 0);
}

bool InputManager::KeyReleased(SDL_Scancode scanCode) {
	return (mPrevKeyState[scanCode]) != 0 && (mKeyState[scanCode] == 0);
}


Vector2 InputManager::MousePos() {
	return Vector2((float)mMousex, (float)mMousey);
}

bool InputManager::MouseButtonDown(MOUSE_BUTTON button) {
	Uint32 mask = 0;

	switch (button){	
		case left:
			mask = SDL_BUTTON_LMASK; 
			break; 

		case right: 
			mask = SDL_BUTTON_RMASK; 
			break; 

		case middle: 
			mask = SDL_BUTTON_MMASK; 
			break;

		case back: 
			mask =SDL_BUTTON_X1MASK;  
			break;

		case forward: 
			mask = SDL_BUTTON_X2MASK;
			break;  
		}

	return ((mMouseState & mask) != 0); 
}

bool InputManager::MouseButtonPressed(MOUSE_BUTTON button) {
	Uint32 mask = 0;

	switch (button) {
		case left:
			mask = SDL_BUTTON_LMASK;
			break;

		case right:
			mask = SDL_BUTTON_RMASK;
			break;

		case middle:
			mask = SDL_BUTTON_MMASK;
			break;

		case back:
			mask = SDL_BUTTON_X1MASK;
			break;

		case forward:
			mask = SDL_BUTTON_X2MASK;
			break;
		}

	return ((mPrevMouseState & mask) == 0 ) && ((mMouseState & mask) != 0);
}

bool InputManager::MouseButtonReleased(MOUSE_BUTTON button) {
	Uint32 mask = 0;

	switch (button) {
		case left:
			mask = SDL_BUTTON_LMASK;
			break;

		case right:
			mask = SDL_BUTTON_RMASK;
			break;

		case middle:
			mask = SDL_BUTTON_MMASK;
			break;

		case back:
			mask = SDL_BUTTON_X1MASK;
			break;

		case forward:
			mask = SDL_BUTTON_X2MASK;
			break;
		}

	return ((mPrevMouseState & mask) != 0) && ((mMouseState & mask) == 0);
}

void InputManager::Update() {
	mMouseState = SDL_GetMouseState(&mMousex, &mMousey);
}

void InputManager::UpdatePrevInp() {
	memcpy(mPrevKeyState, mKeyState, mKeyLength);
	mPrevMouseState = mMouseState; 
}